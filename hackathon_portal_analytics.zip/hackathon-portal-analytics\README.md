# Hackathon Portal Analytics System (Without Bootstrap)

An end-to-end MVC architecture Web Application with Sentiment Analysis Engine and Analytics Dashboard.

## Architecture & Features
- **Frontend (View Layer)**: Pure Vanilla CSS3 (Without Bootstrap), HTML5, JavaScript, Chart.js.
- **Backend (Controller Layer)**: Python Flask with Blueprint controllers for Auth, Admin, Organizer, Participant, Judge, and Analytics.
- **Service Layer (Business Logic)**: User, Team, Hackathon, Submission, Evaluation, Feedback, Analytics, and Sentiment Service.
- **Sentiment Analysis Flow**: Feedback Text -> Text Preprocessing -> VADER Sentiment Analyzer -> Sentiment Score (Pos/Neu/Neg) -> SQLite DB.
- **Model Layer (Data Access Layer)**: SQLAlchemy ORM models.
- **Database Layer**: SQLite.
- **Reports & Export**: CSV Analytics Report generator.

## How to Run

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Seed Database**:
   ```bash
   python seed.py
   ```

3. **Run Application**:
   ```bash
   python run.py
   ```

4. **Access Portal**:
   Open `http://127.0.0.1:5000` in your web browser.
