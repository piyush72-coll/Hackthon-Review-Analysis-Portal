from flask import Flask
from app.config import Config
from app.extensions import db

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)

    # Register blueprints
    from app.controllers import (
        auth_bp, admin_bp, organizer_bp,
        participant_bp, judge_bp, analytics_bp
    )
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(organizer_bp)
    app.register_blueprint(participant_bp)
    app.register_blueprint(judge_bp)
    app.register_blueprint(analytics_bp)

    # Shell context for CLI
    @app.shell_context_processor
    def make_shell_context():
        import app.models as models
        return {'db': db, **models.__dict__}

    return app
