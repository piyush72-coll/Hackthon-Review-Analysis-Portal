from app.controllers.auth_controller import auth_bp
from app.controllers.admin_controller import admin_bp
from app.controllers.organizer_controller import organizer_bp
from app.controllers.participant_controller import participant_bp
from app.controllers.judge_controller import judge_bp
from app.controllers.analytics_controller import analytics_bp

__all__ = [
    'auth_bp',
    'admin_bp',
    'organizer_bp',
    'participant_bp',
    'judge_bp',
    'analytics_bp'
]
