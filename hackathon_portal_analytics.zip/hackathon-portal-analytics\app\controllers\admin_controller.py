from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app.models import User, Hackathon
from app.extensions import db

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/users')
def users_list():
    users = User.query.all()
    return render_template('dashboards/admin.html', users=users)

@admin_bp.route('/hackathon/create', methods=['GET', 'POST'])
def create_hackathon():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        category = request.form.get('category', 'AI/ML')
        
        from app.services import HackathonService
        from datetime import datetime, timedelta
        end_date = datetime.utcnow() + timedelta(days=14)
        
        user_id = session.get('user_id', 1)
        HackathonService.create_hackathon(title, description, category, end_date, user_id)
        flash('Hackathon created successfully!', 'success')
        return redirect(url_for('analytics.dashboard'))
        
    return render_template('hackathons/create.html')
