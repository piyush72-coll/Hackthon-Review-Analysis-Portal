from flask import Blueprint, render_template, jsonify, request, Response, session
from app.services import AnalyticsService, SentimentService, FeedbackService, SubmissionService, HackathonService
from app.models import Feedback

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/')
@analytics_bp.route('/dashboard')
def dashboard():
    metrics = AnalyticsService.get_dashboard_metrics()
    hackathons = HackathonService.get_all()
    feedbacks = Feedback.query.order_by(Feedback.created_at.desc()).limit(10).all()
    return render_template(
        'dashboards/analytics.html',
        metrics=metrics,
        hackathons=hackathons,
        feedbacks=feedbacks
    )

@analytics_bp.route('/api/analytics/metrics')
def api_metrics():
    hackathon_id = request.args.get('hackathon_id', type=int)
    metrics = AnalyticsService.get_dashboard_metrics(hackathon_id=hackathon_id)
    return jsonify(metrics)

@analytics_bp.route('/api/sentiment/analyze', methods=['POST'])
def api_analyze_sentiment():
    data = request.get_json() or {}
    text = data.get('text', '')
    res = SentimentService.analyze_sentiment(text)
    return jsonify(res)

@analytics_bp.route('/api/feedback/submit', methods=['POST'])
def api_submit_feedback():
    data = request.get_json() or {}
    text = data.get('text', '')
    hackathon_id = data.get('hackathon_id', 1)
    user_id = session.get('user_id', 1)

    if not text:
        return jsonify({'error': 'Feedback text is required'}), 400

    fb = FeedbackService.submit_feedback(user_id=user_id, feedback_text=text, hackathon_id=hackathon_id)
    return jsonify({'success': True, 'feedback': fb.to_dict()})

@analytics_bp.route('/reports/leaderboard')
def leaderboard():
    submissions = SubmissionService.get_all()
    # Sort by average score descending
    sorted_submissions = sorted(submissions, key=lambda s: s.average_score, reverse=True)
    return render_template('reports/leaderboard.html', submissions=sorted_submissions)

@analytics_bp.route('/reports/export')
def export_csv():
    csv_data = AnalyticsService.generate_csv_report()
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=hackathon_analytics_report.csv"}
    )
