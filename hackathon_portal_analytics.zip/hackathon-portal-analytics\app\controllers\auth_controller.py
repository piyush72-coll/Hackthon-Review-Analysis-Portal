from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app.services import UserService

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = UserService.get_by_username(username)

        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            flash(f'Welcome back, {user.username} ({user.role})!', 'success')
            return redirect(url_for('analytics.dashboard'))
        else:
            flash('Invalid username or password.', 'error')

    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role', 'Participant')

        if UserService.get_by_username(username):
            flash('Username already exists.', 'error')
        else:
            user = UserService.create_user(username, email, password, role)
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            flash('Registration successful!', 'success')
            return redirect(url_for('analytics.dashboard'))

    return render_template('auth/register.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('auth.login'))
