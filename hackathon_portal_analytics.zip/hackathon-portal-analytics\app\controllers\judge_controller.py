from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app.services import SubmissionService, EvaluationService

judge_bp = Blueprint('judge', __name__, url_prefix='/judge')

@judge_bp.route('/evaluations')
def list_submissions():
    submissions = SubmissionService.get_all()
    return render_template('evaluations/list.html', submissions=submissions)

@judge_bp.route('/evaluate/<int:submission_id>', methods=['GET', 'POST'])
def evaluate_submission(submission_id):
    submission = SubmissionService.get_by_id(submission_id)
    if not submission:
        flash('Submission not found.', 'error')
        return redirect(url_for('judge.list_submissions'))

    if request.method == 'POST':
        innovation = float(request.form.get('innovation', 80))
        execution = float(request.form.get('execution', 80))
        impact = float(request.form.get('impact', 80))
        overall_score = round((innovation + execution + impact) / 3, 1)
        feedback_text = request.form.get('feedback_text', '')
        judge_id = session.get('user_id', 1)

        EvaluationService.add_evaluation(
            submission_id=submission_id,
            judge_id=judge_id,
            score=overall_score,
            innovation_score=innovation,
            execution_score=execution,
            impact_score=impact,
            feedback_text=feedback_text
        )
        flash(f'Evaluation submitted! Overall Score: {overall_score}%', 'success')
        return redirect(url_for('analytics.dashboard'))

    return render_template('evaluations/evaluate.html', submission=submission)
