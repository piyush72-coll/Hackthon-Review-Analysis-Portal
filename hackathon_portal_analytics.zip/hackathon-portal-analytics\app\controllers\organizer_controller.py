from flask import Blueprint, render_template, session
from app.services import HackathonService, TeamService, SubmissionService

organizer_bp = Blueprint('organizer', __name__, url_prefix='/organizer')

@organizer_bp.route('/dashboard')
def dashboard():
    hackathons = HackathonService.get_all()
    submissions = SubmissionService.get_all()
    return render_template('dashboards/organizer.html', hackathons=hackathons, submissions=submissions)
