from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app.services import SubmissionService, HackathonService, TeamService, FeedbackService

participant_bp = Blueprint('participant', __name__, url_prefix='/participant')

@participant_bp.route('/dashboard')
def dashboard():
    submissions = SubmissionService.get_all()
    return render_template('dashboards/participant.html', submissions=submissions)

@participant_bp.route('/submit', methods=['GET', 'POST'])
def submit_project():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        category = request.form.get('category', 'Web')
        repo_url = request.form.get('repo_url')
        demo_url = request.form.get('demo_url')
        hackathon_id = request.form.get('hackathon_id', 1, type=int)
        
        # Check team or default
        user_id = session.get('user_id', 1)
        team = TeamService.create_team(f"Team {title}", hackathon_id, user_id)
        
        SubmissionService.create_submission(title, description, category, repo_url, demo_url, hackathon_id, team.id)
        flash('Project submitted successfully!', 'success')
        return redirect(url_for('analytics.dashboard'))

    hackathons = HackathonService.get_all()
    return render_template('submissions/submit.html', hackathons=hackathons)
