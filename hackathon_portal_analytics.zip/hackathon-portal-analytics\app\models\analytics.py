from datetime import datetime
from app.extensions import db

class HackathonAnalytics(db.Model):
    __tablename__ = 'hackathon_analytics'

    id = db.Column(db.Integer, primary_key=True)
    hackathon_id = db.Column(db.Integer, db.ForeignKey('hackathons.id'), nullable=False)
    total_teams = db.Column(db.Integer, default=0)
    total_participants = db.Column(db.Integer, default=0)
    total_submissions = db.Column(db.Integer, default=0)
    average_score = db.Column(db.Float, default=0.0)
    positive_sentiment_percent = db.Column(db.Float, default=0.0)
    neutral_sentiment_percent = db.Column(db.Float, default=0.0)
    negative_sentiment_percent = db.Column(db.Float, default=0.0)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'hackathon_id': self.hackathon_id,
            'total_teams': self.total_teams,
            'total_participants': self.total_participants,
            'total_submissions': self.total_submissions,
            'average_score': self.average_score,
            'positive_sentiment': self.positive_sentiment_percent,
            'neutral_sentiment': self.neutral_sentiment_percent,
            'negative_sentiment': self.negative_sentiment_percent,
            'last_updated': self.last_updated.strftime('%Y-%m-%d %H:%M')
        }
