from datetime import datetime
from app.extensions import db

class Evaluation(db.Model):
    __tablename__ = 'evaluations'

    id = db.Column(db.Integer, primary_key=True)
    submission_id = db.Column(db.Integer, db.ForeignKey('submissions.id'), nullable=False)
    judge_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    score = db.Column(db.Float, nullable=False) # 0 to 100
    innovation_score = db.Column(db.Float, default=0.0)
    execution_score = db.Column(db.Float, default=0.0)
    impact_score = db.Column(db.Float, default=0.0)
    feedback_text = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'submission_id': self.submission_id,
            'judge_name': self.judge.username if self.judge else 'Judge',
            'score': self.score,
            'innovation_score': self.innovation_score,
            'execution_score': self.execution_score,
            'impact_score': self.impact_score,
            'feedback_text': self.feedback_text,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M')
        }
