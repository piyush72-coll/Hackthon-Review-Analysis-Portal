from datetime import datetime
from app.extensions import db

class Feedback(db.Model):
    __tablename__ = 'feedbacks'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    hackathon_id = db.Column(db.Integer, db.ForeignKey('hackathons.id'), nullable=True)
    feedback_text = db.Column(db.Text, nullable=False)
    sentiment_compound = db.Column(db.Float, default=0.0) # VADER compound score (-1.0 to 1.0)
    sentiment_label = db.Column(db.String(20), default='Neutral') # Positive, Neutral, Negative
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_name': self.author.username if self.author else 'Anonymous',
            'user_role': self.author.role if self.author else 'Participant',
            'feedback_text': self.feedback_text,
            'sentiment_compound': self.sentiment_compound,
            'sentiment_label': self.sentiment_label,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M')
        }
