from datetime import datetime
from app.extensions import db

class Hackathon(db.Model):
    __tablename__ = 'hackathons'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), default='General') # AI/ML, Web, IoT, Mobile, Blockchain
    status = db.Column(db.String(20), default='Active') # Upcoming, Active, Completed
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    teams = db.relationship('Team', backref='hackathon', lazy=True)
    submissions = db.relationship('Submission', backref='hackathon', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'category': self.category,
            'status': self.status,
            'start_date': self.start_date.strftime('%Y-%m-%d'),
            'end_date': self.end_date.strftime('%Y-%m-%d'),
            'team_count': len(self.teams),
            'submission_count': len(self.submissions)
        }
