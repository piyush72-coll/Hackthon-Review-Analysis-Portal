from datetime import datetime
from app.extensions import db

class Submission(db.Model):
    __tablename__ = 'submissions'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    repo_url = db.Column(db.String(255), nullable=True)
    demo_url = db.Column(db.String(255), nullable=True)
    category = db.Column(db.String(50), default='Web')
    hackathon_id = db.Column(db.Integer, db.ForeignKey('hackathons.id'), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    evaluations = db.relationship('Evaluation', backref='submission', lazy=True)

    @property
    def average_score(self):
        if not self.evaluations:
            return 0.0
        return round(sum(e.score for e in self.evaluations) / len(self.evaluations), 1)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'repo_url': self.repo_url,
            'demo_url': self.demo_url,
            'category': self.category,
            'hackathon_id': self.hackathon_id,
            'team_id': self.team_id,
            'team_name': self.team.name if self.team else 'N/A',
            'average_score': self.average_score,
            'evaluation_count': len(self.evaluations)
        }
