from datetime import datetime
from app.extensions import db

class Team(db.Model):
    __tablename__ = 'teams'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    hackathon_id = db.Column(db.Integer, db.ForeignKey('hackathons.id'), nullable=False)
    leader_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    member_count = db.Column(db.Integer, default=4)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    leader = db.relationship('User', foreign_keys=[leader_id])
    submissions = db.relationship('Submission', backref='team', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'hackathon_id': self.hackathon_id,
            'leader_name': self.leader.username if self.leader else 'N/A',
            'member_count': self.member_count,
            'created_at': self.created_at.strftime('%Y-%m-%d')
        }
