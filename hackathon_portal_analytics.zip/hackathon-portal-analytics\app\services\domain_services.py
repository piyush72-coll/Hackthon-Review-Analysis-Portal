from app.extensions import db
from app.models import User, Hackathon, Team, Submission, Evaluation, Feedback

class UserService:
    @staticmethod
    def get_by_id(user_id):
        return User.query.get(user_id)

    @staticmethod
    def get_by_username(username):
        return User.query.filter_by(username=username).first()

    @staticmethod
    def create_user(username, email, password, role='Participant'):
        user = User(username=username, email=email, role=role)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        return user

class HackathonService:
    @staticmethod
    def get_all():
        return Hackathon.query.order_by(Hackathon.start_date.desc()).all()

    @staticmethod
    def get_by_id(hackathon_id):
        return Hackathon.query.get(hackathon_id)

    @staticmethod
    def create_hackathon(title, description, category, end_date, created_by):
        hackathon = Hackathon(
            title=title,
            description=description,
            category=category,
            end_date=end_date,
            created_by=created_by
        )
        db.session.add(hackathon)
        db.session.commit()
        return hackathon

class TeamService:
    @staticmethod
    def get_by_hackathon(hackathon_id):
        return Team.query.filter_by(hackathon_id=hackathon_id).all()

    @staticmethod
    def create_team(name, hackathon_id, leader_id, member_count=4):
        team = Team(name=name, hackathon_id=hackathon_id, leader_id=leader_id, member_count=member_count)
        db.session.add(team)
        db.session.commit()
        return team

class SubmissionService:
    @staticmethod
    def get_all():
        return Submission.query.order_by(Submission.created_at.desc()).all()

    @staticmethod
    def get_by_id(submission_id):
        return Submission.query.get(submission_id)

    @staticmethod
    def create_submission(title, description, category, repo_url, demo_url, hackathon_id, team_id):
        submission = Submission(
            title=title,
            description=description,
            category=category,
            repo_url=repo_url,
            demo_url=demo_url,
            hackathon_id=hackathon_id,
            team_id=team_id
        )
        db.session.add(submission)
        db.session.commit()
        return submission

class EvaluationService:
    @staticmethod
    def add_evaluation(submission_id, judge_id, score, innovation_score=0, execution_score=0, impact_score=0, feedback_text=""):
        evaluation = Evaluation(
            submission_id=submission_id,
            judge_id=judge_id,
            score=score,
            innovation_score=innovation_score,
            execution_score=execution_score,
            impact_score=impact_score,
            feedback_text=feedback_text
        )
        db.session.add(evaluation)
        db.session.commit()
        return evaluation

class FeedbackService:
    @staticmethod
    def submit_feedback(user_id, feedback_text, hackathon_id=None):
        from app.services.sentiment_service import SentimentService
        analysis = SentimentService.analyze_sentiment(feedback_text)
        
        fb = Feedback(
            user_id=user_id,
            hackathon_id=hackathon_id,
            feedback_text=feedback_text,
            sentiment_compound=analysis['compound'],
            sentiment_label=analysis['label']
        )
        db.session.add(fb)
        db.session.commit()
        return fb
