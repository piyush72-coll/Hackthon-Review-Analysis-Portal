import re

class SentimentService:
    """
    Implements VADER (Valence Aware Dictionary and sEntiment Reasoner) sentiment analysis
    and text preprocessing flow according to system architecture diagram:
    Feedback Text -> Text Preprocessing -> VADER Sentiment Analyzer -> Sentiment Score -> Store Result
    """
    
    # Lexicon dictionary for sentiment weights (fallback / standalone VADER)
    POSITIVE_WORDS = {
        'great': 3.1, 'excellent': 3.5, 'awesome': 3.2, 'amazing': 3.4, 'good': 2.0,
        'love': 3.2, 'fantastic': 3.3, 'smooth': 2.1, 'helpful': 2.4, 'best': 3.2,
        'outstanding': 3.6, 'brilliant': 3.3, 'well': 1.8, 'seamless': 2.5, 'interactive': 2.0,
        'inspiring': 2.8, 'superb': 3.1, 'intuitive': 2.4, 'fun': 2.3, 'perfect': 3.5,
        'innovative': 2.9, 'clean': 1.9, 'informative': 2.2, 'impressive': 3.0
    }
    
    NEGATIVE_WORDS = {
        'bad': -2.5, 'poor': -2.2, 'horrible': -3.2, 'terrible': -3.3, 'slow': -1.9,
        'confusing': -2.3, 'buggy': -2.6, 'hard': -1.5, 'difficult': -1.8, 'disappointing': -2.8,
        'frustrating': -2.9, 'laggy': -2.4, 'broken': -2.7, 'worst': -3.5, 'hate': -3.0,
        'boring': -2.1, 'unhelpful': -2.5, 'cluttered': -2.0, 'fail': -2.8, 'issue': -1.5
    }

    BOOST_WORDS = {'very': 1.5, 'extremely': 2.0, 'super': 1.8, 'really': 1.4, 'highly': 1.6}
    NEGATION_WORDS = {'not', 'never', 'no', 'cannot', "n't", 'neither', 'nor'}

    @classmethod
    def preprocess_text(cls, text: str) -> list:
        """Text Preprocessing step"""
        if not text:
            return []
        cleaned = re.sub(r'[^\w\s\']', ' ', text.lower())
        tokens = cleaned.split()
        return tokens

    @classmethod
    def analyze_sentiment(cls, text: str) -> dict:
        """
        VADER Sentiment Analyzer logic calculating:
        - compound score (-1.0 to 1.0)
        - classification (Positive, Neutral, Negative)
        """
        tokens = cls.preprocess_text(text)
        if not tokens:
            return {'compound': 0.0, 'pos': 0.0, 'neu': 1.0, 'neg': 0.0, 'label': 'Neutral'}

        total_score = 0.0
        pos_count = 0
        neg_count = 0
        neu_count = 0

        for i, word in enumerate(tokens):
            score = 0.0
            if word in cls.POSITIVE_WORDS:
                score = cls.POSITIVE_WORDS[word]
            elif word in cls.NEGATIVE_WORDS:
                score = cls.NEGATIVE_WORDS[word]
            else:
                neu_count += 1
                continue

            # Check previous word for boost or negation
            if i > 0:
                prev_word = tokens[i-1]
                if prev_word in cls.BOOST_WORDS:
                    score *= cls.BOOST_WORDS[prev_word]
                if prev_word in cls.NEGATION_WORDS or prev_word.endswith("n't"):
                    score *= -0.8

            if score > 0:
                pos_count += 1
            elif score < 0:
                neg_count += 1

            total_score += score

        # Normalization using VADER compound formula: x / sqrt(x^2 + alpha) where alpha = 15
        if total_score == 0:
            compound = 0.0
        else:
            compound = round(total_score / ( (total_score ** 2 + 15) ** 0.5 ), 3)

        # Sentiment Label determination based on VADER thresholds
        if compound >= 0.05:
            label = 'Positive'
        elif compound <= -0.05:
            label = 'Negative'
        else:
            label = 'Neutral'

        return {
            'compound': compound,
            'label': label,
            'pos_count': pos_count,
            'neu_count': neu_count,
            'neg_count': neg_count
        }
