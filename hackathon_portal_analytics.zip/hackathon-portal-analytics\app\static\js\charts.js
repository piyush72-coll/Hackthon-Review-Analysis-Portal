// Chart.js initialization and dynamic data fetching for Hackathon Analytics Dashboard

document.addEventListener('DOMContentLoaded', function () {
    const timelineCtx = document.getElementById('participationChart');
    const scoreCtx = document.getElementById('scoreChart');
    const sentimentCtx = document.getElementById('sentimentChart');

    if (!timelineCtx || !scoreCtx || !sentimentCtx) return;

    // 1. Participation Over Time Line Chart
    const participationChart = new Chart(timelineCtx.getContext('2d'), {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Teams Registered',
                data: [45, 68, 92, 110, 128, 140],
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.15)',
                borderWidth: 3,
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#3b82f6',
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' } },
                y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#9ca3af' } }
            }
        }
    });

    // 2. Score Distribution Doughnut Chart
    const scoreChart = new Chart(scoreCtx.getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: ['80-100', '60-80', '40-60', '20-40', '0-20'],
            datasets: [{
                data: [42, 35, 12, 7, 4],
                backgroundColor: [
                    '#3b82f6',
                    '#06b6d4',
                    '#8b5cf6',
                    '#f59e0b',
                    '#ef4444'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { color: '#9ca3af', boxWidth: 12, font: { size: 11 } }
                }
            },
            cutout: '70%'
        }
    });

    // 3. Feedback Sentiment Pie Chart (Positive, Neutral, Negative)
    const sentimentChart = new Chart(sentimentCtx.getContext('2d'), {
        type: 'pie',
        data: {
            labels: ['Positive 68%', 'Neutral 21%', 'Negative 11%'],
            datasets: [{
                data: [68, 21, 11],
                backgroundColor: [
                    '#10b981',
                    '#f59e0b',
                    '#ef4444'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { color: '#9ca3af', boxWidth: 12, font: { size: 11 } }
                }
            }
        }
    });

    // Filter change handler
    const hackathonSelect = document.getElementById('hackathonFilter');
    if (hackathonSelect) {
        hackathonSelect.addEventListener('change', function () {
            const hId = this.value;
            fetch(`/api/analytics/metrics?hackathon_id=${hId}`)
                .then(res => res.json())
                .then(data => {
                    document.getElementById('metricTeams').innerText = data.total_teams;
                    document.getElementById('metricParticipants').innerText = data.total_participants;
                    document.getElementById('metricSubmissions').innerText = data.total_submissions;
                    document.getElementById('metricScore').innerText = data.average_score + '%';

                    // Update doughnut
                    const sDist = data.score_distribution;
                    scoreChart.data.datasets[0].data = [
                        sDist['80-100'], sDist['60-80'], sDist['40-60'], sDist['20-40'], sDist['0-20']
                    ];
                    scoreChart.update();

                    // Update sentiment
                    const s = data.sentiment;
                    sentimentChart.data.labels = [
                        `Positive ${s.positive}%`,
                        `Neutral ${s.neutral}%`,
                        `Negative ${s.negative}%`
                    ];
                    sentimentChart.data.datasets[0].data = [s.positive, s.neutral, s.negative];
                    sentimentChart.update();
                });
        });
    }
});
