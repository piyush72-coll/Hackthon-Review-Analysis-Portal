// Sentiment Analysis Flow Interactivity & Tester

document.addEventListener('DOMContentLoaded', function () {
    const feedbackInput = document.getElementById('feedbackText');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const submitFbBtn = document.getElementById('submitFeedbackBtn');
    const sentimentResult = document.getElementById('sentimentResult');

    if (analyzeBtn && feedbackInput) {
        analyzeBtn.addEventListener('click', function () {
            const text = feedbackInput.value.trim();
            if (!text) return;

            fetch('/api/sentiment/analyze', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: text })
            })
                .then(res => res.json())
                .then(data => {
                    let badgeClass = 'badge-neutral';
                    if (data.label === 'Positive') badgeClass = 'badge-positive';
                    else if (data.label === 'Negative') badgeClass = 'badge-negative';

                    sentimentResult.innerHTML = `
                    <div style="margin-top: 15px; padding: 12px; background: rgba(255,255,255,0.05); border-radius: 8px; border: 1px solid var(--border-color);">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span class="badge ${badgeClass}">${data.label.toUpperCase()}</span>
                            <span style="font-size: 0.85rem; color: var(--text-muted);">Compound Score: <strong>${data.compound}</strong></span>
                        </div>
                        <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 8px;">VADER Tokens: ${data.pos_count} positive, ${data.neu_count} neutral, ${data.neg_count} negative</p>
                    </div>
                `;
                });
        });
    }

    if (submitFbBtn && feedbackInput) {
        submitFbBtn.addEventListener('click', function () {
            const text = feedbackInput.value.trim();
            if (!text) return;

            fetch('/api/feedback/submit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: text })
            })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert('Feedback submitted and analyzed successfully!');
                        window.location.reload();
                    }
                });
        });
    }
});
