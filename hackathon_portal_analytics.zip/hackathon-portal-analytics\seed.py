from datetime import datetime, timedelta
from app import create_app
from app.extensions import db
from app.models import User, Hackathon, Team, Submission, Evaluation, Feedback
from app.services import SentimentService

app = create_app()

def seed_database():
    with app.app_context():
        print("Recreating database tables...")
        db.drop_all()
        db.create_all()

        print("Seeding stakeholders matching architecture diagram...")
        # Stakeholders: Admin, Organizer, Participant, Judge, Mentor
        admin = User(username='admin', email='admin@hackathon.org', role='Admin')
        admin.set_password('admin123')

        organizer = User(username='organizer_sarah', email='sarah@organizer.com', role='Organizer')
        organizer.set_password('organizer123')

        participant = User(username='dev_alex', email='alex@dev.com', role='Participant')
        participant.set_password('part123')

        judge = User(username='judge_elena', email='elena@judge.org', role='Judge')
        judge.set_password('judge123')

        mentor = User(username='mentor_david', email='david@mentor.org', role='Mentor')
        mentor.set_password('mentor123')

        db.session.add_all([admin, organizer, participant, judge, mentor])
        db.session.commit()

        print("Seeding Hackathons...")
        h1 = Hackathon(
            title="Global AI & Web Innovation Challenge 2026",
            description="Build state of the art web applications and AI tools with custom analytics.",
            category="AI/ML",
            status="Active",
            start_date=datetime.utcnow() - timedelta(days=10),
            end_date=datetime.utcnow() + timedelta(days=20),
            created_by=organizer.id
        )
        h2 = Hackathon(
            title="IoT & Smart City Hackathon",
            description="Edge computing and smart hardware integrations.",
            category="IoT",
            status="Active",
            start_date=datetime.utcnow() - timedelta(days=5),
            end_date=datetime.utcnow() + timedelta(days=25),
            created_by=organizer.id
        )
        db.session.add_all([h1, h2])
        db.session.commit()

        print("Seeding Teams & Submissions...")
        teams_data = [
            ("Alpha AI Labs", "AI EcoTracker Portal", "AI/ML", 92.5, "https://github.com/alpha/eco", "https://eco.demo"),
            ("Cyber WebCrafters", "Hackathon Analytics Platform", "Web", 88.0, "https://github.com/web/analytics", "https://analytics.demo"),
            ("SmartEdge IoT", "Smart Grid Monitor", "IoT", 79.5, "https://github.com/iot/grid", "https://grid.demo"),
            ("Mobile Health", "PulseCare Mobile App", "Mobile", 84.0, "https://github.com/mob/pulsecare", "https://pulse.demo"),
            ("Neural Vision", "Autonomous Drone Pipeline", "AI/ML", 95.0, "https://github.com/neural/drone", "https://drone.demo")
        ]

        for team_name, proj_title, cat, target_score, repo, demo in teams_data:
            t = Team(name=team_name, hackathon_id=h1.id, leader_id=participant.id, member_count=4)
            db.session.add(t)
            db.session.commit()

            sub = Submission(
                title=proj_title,
                description=f"Advanced {cat} application submitted for Global AI Challenge.",
                category=cat,
                repo_url=repo,
                demo_url=demo,
                hackathon_id=h1.id,
                team_id=t.id
            )
            db.session.add(sub)
            db.session.commit()

            # Add Evaluation
            eval_record = Evaluation(
                submission_id=sub.id,
                judge_id=judge.id,
                score=target_score,
                innovation_score=target_score + 2,
                execution_score=target_score - 2,
                impact_score=target_score,
                feedback_text="Outstanding execution, clean MVC structure, and excellent UI design."
            )
            db.session.add(eval_record)

        print("Seeding Feedbacks & Running VADER Sentiment Pipeline...")
        sample_feedbacks = [
            "The hackathon analytics dashboard is extremely impressive and interactive!",
            "Great platform architecture with clear role-based access control.",
            "The sentiment analysis feedback engine works smoothly and reliably.",
            "Interface loading was decent, clean UI page navigation.",
            "Submissions table could use a few more sorting filters.",
            "Very frustrating bug when submitting without filling repo link.",
            "Fantastic organization, helpful mentors, and brilliant judging panel!"
        ]

        for text in sample_feedbacks:
            analysis = SentimentService.analyze_sentiment(text)
            fb = Feedback(
                user_id=participant.id,
                hackathon_id=h1.id,
                feedback_text=text,
                sentiment_compound=analysis['compound'],
                sentiment_label=analysis['label']
            )
            db.session.add(fb)

        db.session.commit()
        print("Successfully seeded Hackathon Portal database!")

if __name__ == '__main__':
    seed_database()
